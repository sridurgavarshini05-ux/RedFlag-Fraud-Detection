/* ============================================================
   REDFLAG — THE FRAUD FILES
   Fraud Detection Project
   Analyst: SriDurga Varshini P
   Database: redflag
   Table: transactions

   Project:
   Detect suspicious transaction patterns using MySQL/SQL.

   Patterns:
   P1  - Velocity Fraud
   P2  - Round-Amount Clustering
   P3  - Card Testing
   P4  - Failed Then Succeeded
   P5  - Odd-Hour Concentration
   P6  - Mule Accounts
   P7  - Refund Abuse
   P8  - Merchant Collusion
   P9  - Just-Under-Threshold / Structuring
   P10 - Dormant-Then-Active
   P11 - Velocity Spike
   P12 - Geographic Impossibility
   ============================================================ */


/* ============================================================
   P1 — VELOCITY FRAUD
   ------------------------------------------------------------
   Fraud rule:
   Flag users who make 30 or more transactions on the
   same calendar day.
   ============================================================ */

SELECT
    user_id,
    DATE(txn_time) AS transaction_date,
    COUNT(*) AS daily_transaction_count
FROM transactions
GROUP BY
    user_id,
    DATE(txn_time)
HAVING COUNT(*) >= 30
ORDER BY daily_transaction_count DESC;

/*
FINDINGS:
50 suspect user-days were detected.

Examples:
- User 14569 made 60 transactions on 2024-04-03.
- User 14556 made 60 transactions on 2024-05-28.
*/


/* ============================================================
   P2 — ROUND-AMOUNT CLUSTERING
   ------------------------------------------------------------
   Fraud rule:
   Flag users who make 15 or more transactions using common
   round amounts such as ₹100, ₹200, ₹500, ₹1,000, ₹2,000,
   ₹5,000 and ₹10,000.
   ============================================================ */

SELECT
    user_id,
    COUNT(*) AS round_amount_transaction_count
FROM transactions
WHERE amount IN
    (100, 200, 500, 1000, 2000, 5000, 10000)
GROUP BY user_id
HAVING COUNT(*) >= 15
ORDER BY round_amount_transaction_count DESC;

/*
FINDINGS:
25 suspect users were detected.

Examples:
- User 14533 made 30 round-amount transactions.
- User 14534 made 30 round-amount transactions.
- User 14535 made 30 round-amount transactions.
*/


/* ============================================================
   P3 — CARD TESTING
   ------------------------------------------------------------
   Fraud rule:
   Flag users who make 30 or more transactions below ₹10
   on the same day.

   Very small repeated transactions can indicate testing of a
   stolen or compromised payment method.
   ============================================================ */

SELECT
    user_id,
    DATE(txn_time) AS transaction_date,
    COUNT(*) AS small_transaction_count
FROM transactions
WHERE amount < 10
GROUP BY
    user_id,
    DATE(txn_time)
HAVING COUNT(*) >= 30
ORDER BY small_transaction_count DESC;

/*
FINDINGS:
20 suspect user-days were detected.

Examples:
- User 14569 made 60 transactions below ₹10 on 2024-04-03.
- User 14556 made 60 transactions below ₹10 on 2024-05-28.
*/


/* ============================================================
   P4 — FAILED THEN SUCCEEDED
   ------------------------------------------------------------
   Fraud rule:
   Flag users with at least 20 cases where a FAILED transaction
   is followed within 2 minutes by a SUCCESS transaction of
   the same amount.

   This uses a correlated EXISTS subquery to identify the
   failed-then-successful transaction pattern.
   ============================================================ */

SELECT
    f.user_id,
    COUNT(*) AS failed_then_succeeded_pairs
FROM transactions f
WHERE f.status = 'FAILED'
  AND EXISTS (
      SELECT 1
      FROM transactions s
      WHERE s.user_id = f.user_id
        AND s.status = 'SUCCESS'
        AND s.amount = f.amount
        AND s.txn_time > f.txn_time
        AND s.txn_time <= f.txn_time + INTERVAL 2 MINUTE
  )
GROUP BY f.user_id
HAVING COUNT(*) >= 20
ORDER BY failed_then_succeeded_pairs DESC;

/*
FINDINGS:
25 suspect users were detected.

Examples:
- User 14595 had 35 failed-then-successful pairs.
- User 14593 had 34 such pairs.
- User 14576 had 33 such pairs.
*/


/* ============================================================
   P5 — ODD-HOUR CONCENTRATION
   ------------------------------------------------------------
   Fraud rule:
   Flag users with at least 30 total transactions where
   80% or more occur between 2:00 AM and 5:00 AM.
   ============================================================ */

SELECT
    user_id,
    COUNT(*) AS total_transactions,
    SUM(
        CASE
            WHEN TIME(txn_time) >= '02:00:00'
             AND TIME(txn_time) < '05:00:00'
            THEN 1
            ELSE 0
        END
    ) AS odd_hour_transactions,
    ROUND(
        100.0 * SUM(
            CASE
                WHEN TIME(txn_time) >= '02:00:00'
                 AND TIME(txn_time) < '05:00:00'
                THEN 1
                ELSE 0
            END
        ) / COUNT(*),
        2
    ) AS odd_hour_percentage
FROM transactions
GROUP BY user_id
HAVING COUNT(*) >= 30
   AND SUM(
        CASE
            WHEN TIME(txn_time) >= '02:00:00'
             AND TIME(txn_time) < '05:00:00'
            THEN 1
            ELSE 0
        END
   ) / COUNT(*) >= 0.80
ORDER BY
    odd_hour_percentage DESC,
    total_transactions DESC;

/*
FINDINGS:
5 suspect users were detected.

Examples:
- User 14605 had 84.00% of transactions during odd hours.
- User 14604 had 82.61%.
- User 14612 had 82.61%.
*/


/* ============================================================
   P6 — MULE ACCOUNTS
   ------------------------------------------------------------
   Fraud rule:
   Flag users with at least 5 cases where a CREDIT transaction
   is followed within 30 minutes by a DEBIT transaction that
   is at least 70% of the credit amount.

   This identifies rapid movement of received funds.
   ============================================================ */

SELECT
    c.user_id,
    COUNT(*) AS credit_debit_pairs
FROM transactions c
WHERE c.txn_type = 'CREDIT'
  AND EXISTS (
      SELECT 1
      FROM transactions d
      WHERE d.user_id = c.user_id
        AND d.txn_type = 'DEBIT'
        AND d.txn_time > c.txn_time
        AND d.txn_time <= c.txn_time + INTERVAL 30 MINUTE
        AND d.amount >= 0.70 * c.amount
  )
GROUP BY c.user_id
HAVING COUNT(*) >= 5
ORDER BY credit_debit_pairs DESC;

/*
FINDINGS:
30 suspect users were detected.

Examples:
- User 14637 had 15 credit-debit pairs.
- User 14640 had 15 credit-debit pairs.
- User 14645 had 15 credit-debit pairs.
*/


/* ============================================================
   P7 — REFUND ABUSE
   ------------------------------------------------------------
   Fraud rule:
   Flag users with at least 20 transactions where more than
   40% of their transactions are REFUND transactions.
   ============================================================ */

SELECT
    user_id,
    COUNT(*) AS total_transactions,
    SUM(
        CASE
            WHEN txn_type = 'REFUND' THEN 1
            ELSE 0
        END
    ) AS refund_transactions,
    ROUND(
        100.0 * SUM(
            CASE
                WHEN txn_type = 'REFUND' THEN 1
                ELSE 0
            END
        ) / COUNT(*),
        2
    ) AS refund_percentage
FROM transactions
GROUP BY user_id
HAVING COUNT(*) >= 20
   AND SUM(
        CASE
            WHEN txn_type = 'REFUND' THEN 1
            ELSE 0
        END
   ) / COUNT(*) > 0.40
ORDER BY
    refund_percentage DESC,
    total_transactions DESC;

/*
FINDINGS:
24 suspect users were detected.

Examples:
- User 14662 had a refund rate of 64.10%.
- User 14670 had a refund rate of 64.00%.
- User 14665 had a refund rate of 63.89%.
*/


/* ============================================================
   P8 — MERCHANT COLLUSION
   ------------------------------------------------------------
   Fraud rule:
   For each merchant, calculate the transaction value generated
   by its top 5 users.

   Flag merchants where the top 5 users contribute more than
   60% of the merchant's total transaction value.

   ROW_NUMBER() is used to rank users within each merchant.
   ============================================================ */

WITH user_merchant_value AS (
    SELECT
        merchant_id,
        user_id,
        SUM(amount) AS user_value
    FROM transactions
    GROUP BY
        merchant_id,
        user_id
),

ranked_users AS (
    SELECT
        merchant_id,
        user_id,
        user_value,
        ROW_NUMBER() OVER (
            PARTITION BY merchant_id
            ORDER BY user_value DESC
        ) AS user_rank
    FROM user_merchant_value
),

merchant_totals AS (
    SELECT
        merchant_id,
        SUM(amount) AS merchant_total_value
    FROM transactions
    GROUP BY merchant_id
),

top_five AS (
    SELECT
        merchant_id,
        SUM(user_value) AS top_five_value
    FROM ranked_users
    WHERE user_rank <= 5
    GROUP BY merchant_id
)

SELECT
    t.merchant_id,
    t.top_five_value,
    m.merchant_total_value,
    ROUND(
        100.0 * t.top_five_value / m.merchant_total_value,
        2
    ) AS top_five_percentage
FROM top_five t
JOIN merchant_totals m
    ON t.merchant_id = m.merchant_id
WHERE t.top_five_value / m.merchant_total_value > 0.60
ORDER BY top_five_percentage DESC;

/*
FINDINGS:
15 suspect merchants were detected.

Examples:
- Merchant 12: top 5 users contributed 99.91% of total value.
- Merchant 8: top 5 users contributed 99.87%.
- Merchant 13: top 5 users contributed 99.85%.
*/


/* ============================================================
   P9 — JUST-UNDER-THRESHOLD / STRUCTURING
   ------------------------------------------------------------
   Fraud rule:
   Flag users who make at least 10 transactions of exactly
   ₹9,999.

   Repeated transactions just below a threshold can indicate
   deliberate structuring.
   ============================================================ */

SELECT
    user_id,
    COUNT(*) AS threshold_transaction_count
FROM transactions
WHERE amount = 9999
GROUP BY user_id
HAVING COUNT(*) >= 10
ORDER BY threshold_transaction_count DESC;

/*
FINDINGS:
20 suspect users were detected.

Examples:
- User 14680 made 25 transactions of ₹9,999.
- User 14690 made 25 transactions of ₹9,999.
- User 14693 made 22 transactions of ₹9,999.
*/


/* ============================================================
   P10 — DORMANT-THEN-ACTIVE
   ------------------------------------------------------------
   Fraud rule:
   Use LAG() to compare consecutive transactions for each user.

   Flag transactions where a user becomes active again after
   a gap of at least 90 days.
   ============================================================ */

WITH transaction_history AS (
    SELECT
        user_id,
        txn_time,
        LAG(txn_time) OVER (
            PARTITION BY user_id
            ORDER BY txn_time
        ) AS previous_txn_time
    FROM transactions
)

SELECT
    user_id,
    previous_txn_time,
    txn_time AS resumed_txn_time,
    TIMESTAMPDIFF(
        DAY,
        previous_txn_time,
        txn_time
    ) AS dormant_days
FROM transaction_history
WHERE previous_txn_time IS NOT NULL
  AND TIMESTAMPDIFF(
        DAY,
        previous_txn_time,
        txn_time
      ) >= 90
ORDER BY dormant_days DESC;

/*
FINDINGS:
170 suspect users were detected.

Examples:
- User 14708 had a 165-day gap.
- User 14719 had a 152-day gap.
- User 14707 had a 149-day gap.
*/


/* ============================================================
   P11 — VELOCITY SPIKE
   ------------------------------------------------------------
   Fraud rule:
   Calculate monthly transaction counts for each user.

   Flag users where:
   1. Peak monthly transaction count is at least 20.
   2. Peak monthly count is at least 5 times the user's
      average monthly transaction count.
   ============================================================ */

WITH monthly_counts AS (
    SELECT
        user_id,
        DATE_FORMAT(txn_time, '%Y-%m') AS transaction_month,
        COUNT(*) AS monthly_transaction_count
    FROM transactions
    GROUP BY
        user_id,
        DATE_FORMAT(txn_time, '%Y-%m')
),

user_stats AS (
    SELECT
        user_id,
        MAX(monthly_transaction_count) AS peak_monthly_count,
        AVG(monthly_transaction_count) AS average_monthly_count
    FROM monthly_counts
    GROUP BY user_id
)

SELECT
    user_id,
    peak_monthly_count,
    ROUND(average_monthly_count, 2) AS average_monthly_count,
    ROUND(
        peak_monthly_count / average_monthly_count,
        2
    ) AS spike_ratio
FROM user_stats
WHERE peak_monthly_count >= 20
  AND peak_monthly_count / average_monthly_count >= 5
ORDER BY
    spike_ratio DESC,
    peak_monthly_count DESC;

/*
FINDINGS:
3 suspect users were detected.

Examples:
- User 14517 had a peak of 41 transactions and a spike ratio
  of 5.13.
- User 14504 had a peak of 45 transactions and a spike ratio
  of 5.09.
- User 14528 had a peak of 39 transactions and a spike ratio
  of 5.09.
*/


/* ============================================================
   P12 — GEOGRAPHIC IMPOSSIBILITY
   ------------------------------------------------------------
   Fraud rule:
   Use LAG() to compare each transaction with the previous
   transaction of the same user.

   Flag transactions when:
   1. The previous and current cities are different.
   2. The transactions occur within 60 minutes.

   This can indicate impossible or highly suspicious movement
   between geographically distant locations.
   ============================================================ */

WITH transaction_history AS (
    SELECT
        user_id,
        txn_time,
        city,
        LAG(txn_time) OVER (
            PARTITION BY user_id
            ORDER BY txn_time
        ) AS previous_txn_time,
        LAG(city) OVER (
            PARTITION BY user_id
            ORDER BY txn_time
        ) AS previous_city
    FROM transactions
)

SELECT
    user_id,
    previous_city,
    city AS current_city,
    previous_txn_time,
    txn_time AS current_txn_time,
    TIMESTAMPDIFF(
        MINUTE,
        previous_txn_time,
        txn_time
    ) AS minutes_between
FROM transaction_history
WHERE previous_txn_time IS NOT NULL
  AND previous_city <> city
  AND TIMESTAMPDIFF(
        MINUTE,
        previous_txn_time,
        txn_time
      ) <= 60
ORDER BY minutes_between ASC;

/*
FINDINGS:
80 geographic-impossibility transaction instances were detected.

Examples:
- User 14750 moved from Visakhapatnam to Delhi in 1 minute.
- User 14745 moved from Surat to Thiruvananthapuram in 9 minutes.
- User 14745 moved from Nagpur to Visakhapatnam in 15 minutes.
*/


/* ============================================================
   END OF REDFLAG FRAUD DETECTION PROJECT
   ============================================================ */